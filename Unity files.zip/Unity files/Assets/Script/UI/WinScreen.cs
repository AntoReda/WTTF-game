using UnityEngine;
using UnityEngine.SceneManagement;

public class WinScreen : MonoBehaviour
{
    public void ReturnToForge()
    {
        SceneManager.LoadScene(1);
    }
}
